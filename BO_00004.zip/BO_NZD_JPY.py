from ATBO import AutoTrading_BO
from info import get_info

ID, PW, token, price, driver, confidence = get_info()
instrument = "NZD_JPY"
conf = confidence(instrument)
model = "model_" + instrument + "_BO.pickle"
AT = AutoTrading_BO(ID, PW, token, instrument, driver)
AT.run(price, conf, inmodel=model)