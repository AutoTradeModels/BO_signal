def get_info():
    key = '*****************************' #Update by the third day of each month
    ID = "*****************************"
    PW = "*********"
    token = "****************************************************************"
    directory = 'C:/chromedriver_win32/chromedriver.exe'
    model = "BO.pickle"
    price = 1000  # 1000 <= price <= 200000
    alpha = 0.35
    return key, ID, PW, token, directory, model, price, alpha