from ATBO import AutoTrading
from info import get_info

key, ID, PW, token, directory, model, price, alpha = get_info()
AT = AutoTrading(key, ID, PW, token, directory, model, price, alpha)
AT.run()