def get_info():
    key = '*****************************' 
    ID = "*****************************"
    PW = "*********"
    token = "****************************************************************"
    directory = 'C:/chromedriver_win32/chromedriver.exe'
    auto = True
    order_instrument = "//*[@id='6270']/div[1]/div[2]/span"    
    price = 1000  # 1000 <= price <= 200000
    alpha = 0.3
    start_train = '2018-09-01 00:00:00' 
    end_train = '2019-09-01 00:00:00' 
    start_test = '2019-09-01 00:00:00' 
    end_test = '2020-09-01 00:00:00'         
    return key, ID, PW, token, directory, auto, order_instrument, price, alpha, start_train, end_train, start_test, end_test