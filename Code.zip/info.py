def get_info():
    key = '*****************************' 
    ID = "*****************************"
    PW = "*********"
    token = "****************************************************************"
    directory = 'C:/chromedriver_win32/chromedriver.exe'
    auto = True
    order_instrument = "//*[@id='6270']/div[1]/div[2]/span"    
    price = 1000  # 1000 <= price <= 200000
    alpha = 0.3
    return key, ID, PW, token, directory, auto, order_instrument, price, alpha