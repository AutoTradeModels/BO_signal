from ATBO import AutoTrading
from info import get_info

key, ID, PW, token, directory, auto, order_instrument, price, alpha, start_train, end_train, start_test, end_test = get_info()
ATBO = AutoTrading(key, ID, PW, token, directory, auto, order_instrument, price, alpha)
ATBO.run()