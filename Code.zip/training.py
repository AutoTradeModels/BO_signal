from ATBO import AutoTrading
from info import get_info
import pickle

key, ID, PW, token, directory, auto, order_instrument, price, alpha, start_train, end_train, start_test, end_test = get_info()
ATBO = AutoTrading(key, ID, PW, token, directory, auto, order_instrument, price, alpha, training=True)
ATBO.train(start_train, end_train)
ATBO.test(start_test, end_test)
with open("BO.pickle", mode='wb') as fp:
    pickle.dump(ATBO.LFGP_High, fp)
    pickle.dump(ATBO.LFGP_Low, fp)