import time
from ATBO import AutoTrading_BO
from info import get_info

time.sleep(0)
ID, PW, token, price, driver, confidence = get_info()
instrument = "USD_JPY"
conf = confidence(instrument)
model = "model_" + instrument + "_BO_2019.pickle"
AT = AutoTrading_BO(ID, PW, token, instrument, driver)
AT.run(price, conf, inmodel=model)