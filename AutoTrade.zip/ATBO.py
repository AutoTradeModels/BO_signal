import datetime
import time
import pickle
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from info import get_info
No, ID, PW, token, price, driver, confidence = get_info()
import sys
sys.path.append("./BO_" + No)
from BO import BinaryOption

class AutoTrading_BO:
    
    def __init__(self, ID, PW, token, instrument, driver):
        self.ID = ID
        self.PW = PW
        self.BO = BinaryOption(ID, token, instrument)
        self.instrument = instrument
        self.driver = webdriver.Chrome(driver)
        if self.instrument == "USD_JPY" :
            self.order_instrument = "//*[@id='6430']/div[1]"
        elif self.instrument == "EUR_USD" :
            self.order_instrument = "//*[@id='6400']/div[1]"
        elif self.instrument == "EUR_JPY" :
            self.order_instrument = "//*[@id='6250']/div[1]"
        elif self.instrument == "GBP_JPY" :
            self.order_instrument = "//*[@id='6268']/div[1]"
        elif self.instrument == "AUD_JPY" :
            self.order_instrument = "//*[@id='6213']/div[1]"
        elif self.instrument == "AUD_USD" :
            self.order_instrument = "//*[@id='6232']/div[1]"
        elif self.instrument == "NZD_JPY" :
            self.order_instrument = "//*[@id='6337']/div[1]"
    
    def browser(self, price):
        self.driver.get('https://jp.highlow.net/login')
        self.driver.maximize_window()
        self.driver.find_element_by_id('login-username').send_keys(self.ID)
        self.driver.find_element_by_id('login-password').send_keys(self.PW)
        self.driver.find_element_by_class_name("btn").send_keys(Keys.ENTER)
        time.sleep(10)
        self.driver.find_element_by_xpath(
                        "//*[@id='assetsGameTypeZoneRegion']/ul/li[3]").click()
        self.driver.find_element_by_xpath(
                "//*[@id='assetsCategoryFilterZoneRegion']/div/div[3]").click()
        if self.instrument in ["AUD_USD", "NZD_JPY"]:
            self.driver.find_element_by_xpath(
                                         "//*[@id='rightButton']/span").click()
            time.sleep(10)
        self.driver.find_element_by_xpath(self.order_instrument).click()
        time.sleep(10)
        self.driver.find_element_by_xpath("//*[@id='amount']").clear()
        self.driver.find_element_by_xpath("//*[@id='amount']").send_keys(price)
    
    def operation(self, start, end):
        X = self.BO.history_data(start, end)
        myu_High, sigma_High = self.G3P_High.predict(X, self.ID)
        myu_Low, sigma_Low = self.G3P_Low.predict(X, self.ID)
        High = myu_High[0] - sigma_High[0] * self.conf
        Low = myu_Low[0] - sigma_Low[0] * self.conf
        print(self.instrument, datetime.datetime.now(),
              "High", "prob:{:.3f}, {:.3f}".format(myu_High[0], High), 
              "Low ", "prob:{:.3f}, {:.3f}".format(myu_Low[0], Low))
        if High >= Low:
            if High > 100 / 195:
                self.driver.find_element_by_xpath(
                                            "//*[@id='up_button']").click()
                time.sleep(0.1)
                if datetime.datetime.now().second >= 59:
                    self.driver.find_element_by_xpath(
                                        "//*[@id='invest_now_button']").click()
                    print(self.instrument, datetime.datetime.now(), "Order High")
        else:
            if Low > 100 / 195:
                self.driver.find_element_by_xpath(
                                          "//*[@id='down_button']").click()
                time.sleep(0.1)
                if datetime.datetime.now().second >= 59:
                    self.driver.find_element_by_xpath(
                                        "//*[@id='invest_now_button']").click()
                    print(self.instrument, datetime.datetime.now(), "Order Low")
        time.sleep(1)
        
    def run(self, price, conf, inmodel=False, minutes=1000000):
        def W(t):
            if t.month == 12 and t.day >= 24:
                return False
            elif t.month == 1 and t.day <= 8:
                return False
            elif t.weekday() == 6:
                return False
            elif t.weekday() == 5:
                if t.hour >= 5:
                    return False
                else:
                    return True                    
            elif t.weekday() == 0:
                if t.hour < 8:
                    return False
                else:
                    return True
            else:
                if (8 > t.hour >= 5) or (t.hour == 8 and t.minute <= 5) \
                                     or (t.hour == 4 and t.minute >= 55):
                    return False
                else:
                    return True
        self.conf = conf
        if inmodel != False:
            inmodel =  "./BO_" + No + "/" + inmodel
            with open(inmodel, mode='rb') as fp:
                self.G3P_High = pickle.load(fp)
                self.G3P_Low = pickle.load(fp)
        T = self.G3P_High.T
        self.BO.T = T
        time_open = datetime.datetime.now()
        time_close = time_open + datetime.timedelta(minutes=minutes)
        n_browser = 0
        while time_close.timestamp() > datetime.datetime.now().timestamp():
            now = datetime.datetime.now()
            if W(now) == False:
                if n_browser > 0:
                    self.driver.close()
                    n_browser = 0
                    time.sleep(60 * 5)
                else:
                    time.sleep(60 * 5)      
            else:
                if n_browser == 0:
                    try:
                        self.browser(price)
                        n_browser = 1
                    except:
                        self.driver.close()
                        n_browser = 0
                        time.sleep(60 * 1)
                if n_browser > 0:                    
                    now = datetime.datetime.now()
                    if now.second >= 59:
                        try:
                            end = now.replace(second=0, microsecond=0)
                            start = end - datetime.timedelta(minutes=T)
                            self.operation(start, end)
                        except:
                            self.driver.close()
                            n_browser = 0                       
                            time.sleep(60 * 1)
                    else:
                        time.sleep(58 - now.second)