def get_info():
    ID = "xxxxxxxxxxxxxx@xxxxxxxxxx"
    PW = "xxxxxxxx"
    token = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    price = 1000  # 1000 <= price <= 200000
    driver = 'C:/chromedriver_win32/chromedriver.exe'   
    def confidence(instrument):
        if instrument == "USD_JPY" :
            return 0.5
        elif instrument == "EUR_JPY" :
            return 0.5
        elif instrument == "GBP_JPY" :
            return 0.9
        elif instrument == "AUD_JPY" :
            return 0.5
        elif instrument == "NZD_JPY" :
            return 0.5
    return ID, PW, token, price, driver, confidence